# Pagination Guide

Strategies and patterns for extracting data across multiple pages.

## Common Pagination Patterns

### Traditional Page Numbers
```bash
# Look for page number links
nav g https://example.com/listings

# Find pagination elements
nav findall "a[href*='page=']"
nav findall "button:contains('2')"
nav findall "li.page-numbers"

# Extract from page 1
nav tables
nav paragraphs

# Navigate through pages
for page in {2..10}; do
    echo "Processing page $page"
    
    # Try different pagination selectors
    nav c "a[href*='page=$page']" || \
    nav c "button:contains('$page')" || \
    nav c "li.page-numbers a:contains('$page')"
    
    # Wait for page load
    nav wait_idle
    
    # Extract data
    nav tables
    nav paragraphs
    
    # Small delay between pages
    sleep 2
done
```

### "Next" Button Pagination
```bash
nav g https://example.com/articles

# Extract first page
nav tables

# Find and click "Next" button
nav findall "Next"
nav c "a.next" || nav c "button.next" || nav c "a:contains('Next')"

# Wait for next page to load
nav wait_idle

# Extract second page
nav tables

# Continue until no more "Next" buttons
while nav findall "Next"; do
    echo "Processing next page"
    nav c "a.next" || nav c "button.next"
    nav wait_idle
    nav tables
    sleep 2
done
```

### Load More Button
```bash
nav g https://example.com/products

# Extract initial content
nav tables

# Look for "Load More" buttons
nav findall "Load More"
nav findall "Show More"
nav findall "Load Additional"

# Click to load more content
nav c "button.load-more" || nav c "button:contains('Load More')"

# Wait for content to load
nav wait_idle 5

# Check if more content loaded
nav tables

# Repeat until all content is loaded
while nav findall "button.load-more"; do
    nav c "button.load-more"
    nav wait_idle 5
    nav tables
    sleep 2
done
```

### Infinite Scroll
```bash
nav g https://example.com/feed

# Initial content
nav tables

# Scroll to bottom repeatedly
for i in {1..20}; do
    echo "Scroll iteration $i"
    
    # Scroll to bottom
    nav scroll bottom
    
    # Wait for new content to load
    nav wait_idle 3
    
    # Check if new content loaded
    current_tables=$(nav tables)
    
    # If no new content, we might be done
    if [ "$current_tables" = "$previous_tables" ]; then
        echo "No new content loaded, stopping"
        break
    fi
    
    previous_tables="$current_tables"
    sleep 2
done

# Final extraction
nav tables
```

## Advanced Pagination Strategies

### Adaptive Page Detection
```bash
# Function to detect pagination type
detect_pagination_type() {
    nav elements
    
    # Check for page numbers
    if nav findall "a[href*='page=']" >/dev/null; then
        echo "page_numbers"
    elif nav findall "a.next" >/dev/null; then
        echo "next_button"
    elif nav findall "button.load-more" >/dev/null; then
        echo "load_more"
    elif nav findall "a[href*='offset=']" >/dev/null; then
        echo "offset_based"
    else
        echo "unknown"
    fi
}

# Extract data based on detected type
extract_with_detected_pagination() {
    local pagination_type=$(detect_pagination_type)
    echo "Detected pagination type: $pagination_type"
    
    case $pagination_type in
        "page_numbers")
            extract_page_numbers
            ;;
        "next_button")
            extract_next_button
            ;;
        "load_more")
            extract_load_more
            ;;
        "offset_based")
            extract_offset_based
            ;;
        *)
            echo "Unknown pagination type, extracting single page"
            nav tables
            ;;
    esac
}

# Implement specific extraction methods
extract_page_numbers() {
    # Extract all numbered pages
    nav g https://example.com/listings?page=1
    for page in {1..50}; do
        echo "Extracting page $page"
        nav g "https://example.com/listings?page=$page"
        nav wait_idle
        nav tables
        
        # Check if we reached the last page
        if ! nav findall "a[href*='page=$((page+1))']"; then
            echo "Last page reached at $page"
            break
        fi
    done
}

extract_next_button() {
    local page_count=1
    while [ $page_count -le 100 ]; do  # Safety limit
        echo "Extracting page $page_count"
        nav tables
        
        if ! nav findall "a.next"; then
            echo "No more 'Next' buttons found"
            break
        fi
        
        nav c "a.next"
        nav wait_idle
        page_count=$((page_count + 1))
    done
}

extract_load_more() {
    local load_count=1
    while [ $load_count -le 50 ]; do  # Safety limit
        echo "Load more iteration $load_count"
        nav tables
        
        if ! nav findall "button.load-more"; then
            echo "No more 'Load More' buttons found"
            break
        fi
        
        nav c "button.load-more"
        nav wait_idle 5
        load_count=$((load_count + 1))
    done
}

extract_offset_based() {
    local offset=0
    local limit=50
    
    while [ $offset -lt 1000 ]; do  # Safety limit
        echo "Extracting with offset $offset"
        nav g "https://example.com/listings?offset=$offset&limit=$limit"
        nav wait_idle
        
        current_tables=$(nav tables)
        
        # Check if we got any data
        if ! echo "$current_tables" | grep -q "rows"; then
            echo "No more data available"
            break
        fi
        
        nav tables
        
        # Check if we got less than the limit (last page)
        if ! echo "$current_tables" | grep -q "\"rows\": \[\"; then
            echo "Last page reached"
            break
        fi
        
        offset=$((offset + limit))
    done
}
```

### Smart Pagination with Data Validation
```bash
# Extract with duplicate detection
extract_with_deduplication() {
    local seen_data=()
    local page_num=1
    
    while [ $page_num -le 100 ]; do
        echo "Processing page $page_num"
        
        # Extract current page data
        current_data=$(nav tables)
        
        # Check if we got the same data as before
        if [[ " ${seen_data[@]} " =~ " ${current_data} " ]]; then
            echo "Duplicate data detected, stopping"
            break
        fi
        
        # Save current data
        seen_data+=("$current_data")
        
        # Process and save data
        echo "$current_data" > "page_${page_num}_data.json"
        
        # Try to go to next page
        if ! nav findall "a.next" && ! nav findall "button.load-more"; then
            echo "No more pages available"
            break
        fi
        
        # Navigate to next page
        nav c "a.next" || nav c "button.load-more"
        nav wait_idle
        page_num=$((page_num + 1))
    done
}
```

### Multi-Level Pagination
```bash
# Handle categories with pagination
nav g https://example.com/categories

# Get all category links
nav findall "a.category-link" > categories.txt

# Process each category with pagination
while IFS= read -r category_link; do
    echo "Processing category: $category_link"
    
    nav c "$category_link"
    nav wait_idle
    
    # Extract category data with pagination
    while nav findall "a.next"; do
        nav tables
        nav c "a.next"
        nav wait_idle
    done
    
    # Go back to category list
    nav b
    nav wait_idle
    
done < categories.txt
```

## Pagination Error Handling

### Robust Page Navigation
```bash
# Navigate with retry logic
navigate_to_page() {
    local url="$1"
    local max_attempts=3
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        echo "Navigation attempt $attempt to $url"
        
        if nav g "$url"; then
            nav wait_idle
            
            # Verify page loaded correctly
            if nav text | grep -q "error"; then
                echo "Page loaded with error, retrying"
                attempt=$((attempt + 1))
                continue
            fi
            
            echo "Successfully navigated to page"
            return 0
        else
            echo "Navigation failed, retrying"
            attempt=$((attempt + 1))
            sleep 5
        fi
    done
    
    echo "Failed to navigate after $max_attempts attempts"
    return 1
}

# Use with pagination
extract_paginated_with_retry() {
    local base_url="$1"
    local page=1
    
    while [ $page -le 50 ]; do  # Safety limit
        local page_url="${base_url}?page=${page}"
        
        if navigate_to_page "$page_url"; then
            nav tables
            
            # Check if we got meaningful data
            if ! nav text | grep -q "No results"; then
                page=$((page + 1))
            else
                echo "No results found, stopping"
                break
            fi
        else
            echo "Failed to navigate to page $page, stopping"
            break
        fi
    done
}
```

### Rate Limiting and Politeness
```bash
# Respectful pagination with delays
polite_pagination() {
    local base_url="$1"
    local delay="${2:-3}"  # Default 3 second delay
    
    for page in {1..100}; do
        echo "Politely extracting page $page"
        
        nav g "${base_url}?page=${page}"
        nav wait_idle
        
        # Extract data
        nav tables
        nav paragraphs
        
        # Respectful delay before next request
        echo "Waiting ${delay} seconds before next request..."
        sleep $delay
        
        # Check if this was the last page
        if ! nav findall "a.next"; then
            echo "Last page reached"
            break
        fi
    done
}

# Usage
polite_pagination "https://example.com/listings" 5  # 5 second delay
```

## Performance Optimization

### Batch Processing
```bash
# Process multiple pages in batches
batch_extract() {
    local base_url="$1"
    local batch_size=10
    
    for ((i=1; i<=100; i+=batch_size)); do
        echo "Processing batch: pages $i-$((i + batch_size - 1))"
        
        # Start multiple page extractions in background
        for ((page=i; page<i+batch_size; page++)); do
            (
                nav g "${base_url}?page=${page}"
                nav wait_idle
                nav tables > "batch_data/page_${page}.json"
                echo "Completed page $page"
            ) &
        done
        
        # Wait for batch to complete
        wait
        
        echo "Batch $((i/batch_size + 1)) completed"
        
        # Brief pause between batches
        sleep 2
    done
}
```

### Memory Management
```bash
# Process and clean up between pages
memory_efficient_pagination() {
    local base_url="$1"
    
    for page in {1..100}; do
        echo "Processing page $page (memory efficient)"
        
        # Navigate and extract
        nav g "${base_url}?page=${page}"
        nav wait_idle
        
        # Process data immediately
        nav tables | jq '.tables[0].rows' > "processed/page_${page}_rows.json"
        
        # Clear browser state to free memory
        nav clear_cookies
        
        # Optional: Restart browser periodically
        if [ $((page % 20)) -eq 0 ]; then
            echo "Restarting browser to free memory"
            nav quit
            sleep 2
            nav-server --headless
        fi
    done
}
```