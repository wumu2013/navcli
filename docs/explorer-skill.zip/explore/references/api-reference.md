# API Reference

Complete REST API documentation for NavCLI server endpoints.

## Base URL
```
http://localhost:8765
```

## Navigation Endpoints

### Navigate to URL
```http
POST /cmd/goto?url={url}
```

**Parameters:**
- `url` (required): Target URL to navigate to

**Example:**
```bash
curl -X POST "http://localhost:8765/cmd/goto?url=https://example.com"
```

### Browser Navigation
```http
POST /cmd/back                    # Go back in history
POST /cmd/forward                # Go forward in history  
POST /cmd/reload                 # Reload current page
```

## Interaction Endpoints

### Click Element
```http
POST /cmd/click?selector={selector}&force={boolean}
```

**Parameters:**
- `selector` (required): CSS selector for target element
- `force` (optional): Boolean to force click even if not visible

### Type Text
```http
POST /cmd/type?selector={selector}&text={text}
```

**Parameters:**
- `selector` (required): CSS selector for input field
- `text` (required): Text to type

### Other Interactions
```http
POST /cmd/dblclick?selector={selector}      # Double-click element
POST /cmd/rightclick?selector={selector}     # Right-click element
POST /cmd/clear?selector={selector}          # Clear input field
POST /cmd/upload?selector={selector}&file_path={path}  # Upload file
```

## Query Endpoints

### Get Interactive Elements
```http
GET /query/elements
```

**Response:**
```json
{
  "elements": [
    {
      "tag": "button",
      "text": "Click Me",
      "selector": "button.btn-primary",
      "attributes": {
        "id": "submit-btn",
        "class": "btn btn-primary"
      }
    }
  ]
}
```

### Get Page Content
```http
GET /query/text           # Plain text content
GET /query/html           # Full HTML content
GET /query/screenshot     # Screenshot (base64)
GET /query/state          # Complete page state
```

### Get Current Page Info
```http
GET /query/url            # Current URL
GET /query/title          # Page title
```

### Extract Tables
```http
GET /query/tables
```

**Response:**
```json
{
  "tables": [
    {
      "headers": ["Name", "Price", "Stock"],
      "rows": [
        ["Widget A", "$10.99", "150"],
        ["Widget B", "$15.99", "89"]
      ],
      "selector": "table.inventory"
    }
  ]
}
```

### Extract Paragraphs
```http
GET /query/paragraphs?min_length={integer}
```

**Parameters:**
- `min_length` (optional): Minimum character length for paragraphs (default: 200)

**Response:**
```json
{
  "paragraphs": [
    {
      "text": "This is a long paragraph with substantial content...",
      "length": 245,
      "selector": "p.article-content"
    }
  ]
}
```

### Other Query Endpoints
```http
GET /query/links              # All hyperlinks
GET /query/forms              # All forms
GET /query/evaluate?expr={js} # Execute JavaScript
```

## Session Management

### Get Cookies
```http
GET /cmd/cookies
```

### Set Cookie
```http
POST /cmd/cookies/set
Content-Type: application/json

{
  "name": "session_id",
  "value": "abc123",
  "domain": "example.com"
}
```

### Clear Cookies
```http
DELETE /cmd/cookies/clear
```

### Save Session
```http
POST /cmd/session/save?name={name}
```

### Load Session
```http
POST /cmd/session/load?name={name}
```

## Explore Endpoints

### Find Elements
```http
GET /explore/find?text={text}          # Find first element containing text
GET /explore/findall?text={text}       # Find all elements containing text
GET /explore/inspect?selector={selector} # Inspect element details
```

### Wait Operations
```http
POST /explore/wait?selector={selector}  # Wait for element
POST /explore/wait?seconds={n}          # Wait for seconds
POST /explore/wait?idle={boolean}       # Wait for network idle
```

### Scroll Page
```http
POST /explore/scroll?direction={direction}
```

**Parameters:**
- `direction`: `top`, `bottom`, `up`, or `down`

## Control Endpoints

### Browser Control
```http
POST /cmd/quit         # Close browser
POST /cmd/shutdown     # Shutdown server
```

## Error Handling

### Standard Response Format
```json
{
  "success": true,
  "data": { ... },
  "error": null
}
```

### Error Response Format
```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "ELEMENT_NOT_FOUND",
    "message": "Element with selector 'button.submit' not found"
  }
}
```

### Common Error Codes
- `ELEMENT_NOT_FOUND`: Specified element not found
- `NAVIGATION_FAILED`: Could not navigate to URL
- `TIMEOUT`: Operation timed out
- `INVALID_SELECTOR`: Invalid CSS selector provided
- `SERVER_ERROR`: Internal server error

## Rate Limiting
- No rate limiting implemented
- Recommended: Add delays between requests for stability
- Use `wait_idle` endpoint for network-heavy operations