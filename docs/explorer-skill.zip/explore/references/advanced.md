# Advanced Patterns

Complex workflows and advanced techniques for NavCLI data extraction.

## Complex Data Extraction Workflows

### Multi-Step Authentication Flow
```bash
# Navigate to login page
nav g https://secure.example.com/login

# Find login form elements
nav elements

# Fill credentials
nav t "input[name='username']" "myusername"
nav t "input[name='password']" "mypassword"

# Submit form
nav c "button[type='submit']"

# Wait for redirect and verify login
nav wait_idle
nav url
nav text  # Check for welcome message

# Save authenticated session
nav save_session "authenticated"
```

### Dynamic Content Loading
```bash
# Navigate to page with dynamic content
nav g https://example.com/dashboard

# Wait for initial load
nav wait_idle

# Check for loading indicators
nav find "Loading..."
nav find "Please wait"

# Extract initial content
nav tables
nav paragraphs

# Wait for additional content
nav wait_idle 10  # Extended wait for slow content

# Re-extract after dynamic content loads
nav tables
nav paragraphs
```

### Complex Form Interactions
```bash
# Navigate to complex form
nav g https://example.com/complex-form

# Handle dropdown menus
nav c "select[name='category']"
nav t "select[name='category']" "Option 1"

# Handle checkboxes
nav c "input[type='checkbox'][value='option1']"
nav c "input[type='checkbox'][value='option2']"

# Handle date pickers
nav c "input[name='date']"
nav t "input[name='date']" "2024-01-15"

# File uploads
nav upload "input[type='file']" "/path/to/document.pdf"

# Text areas
nav t "textarea[name='description']" "This is a detailed description..."

# Submit form
nav c "button[type='submit']"

# Wait for processing
nav wait_idle
nav text  # Check for success message
```

## Intelligent Navigation Patterns

### Smart Pagination Detection
```bash
nav g https://example.com/paginated-list

# First, extract current page data
nav tables

# Look for pagination elements
nav findall "Next"
nav findall "Page"
nav findall "More"

# Try different pagination patterns
nav findall "a[aria-label='Next']"
nav findall "button:contains('Next')"
nav findall "li.next"

# Navigate through pages
nav c "a.next-page"
nav wait_idle
nav tables

# Continue until no more pages
nav findall "a.next-page"
nav c "a.next-page" 2>/dev/null || echo "No more pages"
nav wait_idle
nav tables
```

### Infinite Scroll Handling
```bash
nav g https://example.com/infinite-scroll

# Scroll to bottom to trigger loading
nav scroll bottom

# Wait for new content to load
nav wait_idle 5

# Extract current content
nav tables

# Repeat scrolling and extraction
nav scroll bottom
nav wait_idle
nav tables

# Continue until all content is loaded
# (This might need a limit to avoid infinite loops)
```

### Modal and Popup Handling
```bash
nav g https://example.com/page-with-modal

# Check for modal triggers
nav find "View Details"
nav c "a.view-details"

# Wait for modal to appear
nav wait_idle
nav find "modal"

# Extract modal content
nav html  # Get modal HTML
nav text  # Get modal text

# Close modal
nav c "button.close"
nav c "[aria-label='Close']"
nav escape  # Press Escape key

# Alternative: Handle popup windows
nav c "a.opens-popup"
nav wait_idle
# Check if new tab/window opened (handled by NavCLI internally)
```

## Error Recovery Strategies

### Robust Element Finding
```bash
# Primary method
nav find "Submit Button"

# Fallback methods
nav findall "button[type='submit']"
nav findall "input[type='submit']"
nav findall "button:contains('Submit')"
nav findall "[data-testid='submit']"

# Use last resort - inspect page elements
nav elements | grep -i submit
```

### Timeout and Retry Logic
```bash
# Function to retry operations
retry_extract() {
    local max_attempts=3
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        echo "Attempt $attempt of $max_attempts"
        
        # Try to extract data
        nav tables
        nav paragraphs
        
        # Check if we got meaningful data
        if nav tables | grep -q "rows"; then
            echo "Data extraction successful"
            break
        else
            echo "No data found, retrying..."
            nav wait_idle 5
            nav r  # Reload page
            attempt=$((attempt + 1))
        fi
    done
}

# Use the retry function
retry_extract
```

### Network Error Handling
```bash
nav g https://unreliable-site.com

# Check page state
nav state

# Handle different error states
nav text | grep -i "error" && echo "Page error detected"
nav text | grep -i "timeout" && echo "Timeout occurred"
nav text | grep -i "maintenance" && echo "Site maintenance"

# Retry with backoff
for i in {1..3}; do
    echo "Retry attempt $i"
    nav r  # Reload
    nav wait_idle
    
    if nav text | grep -v "error"; then
        echo "Page loaded successfully"
        break
    fi
    
    sleep 5  # Wait before retry
done
```

## Data Processing Patterns

### Structured Data Extraction
```bash
# Extract tables with processing
nav g https://example.com/data

# Get raw tables
nav tables > raw_tables.json

# Process with jq or similar
cat raw_tables.json | jq '.tables[] | select(.rows | length > 0)'

# Filter specific data
cat raw_tables.json | jq '.tables[] | select(.headers[] | contains("Price"))'

# Clean and format
cat raw_tables.json | jq -r '.tables[0].rows[] | @csv'
```

### Multi-Source Data Aggregation
```bash
# Extract from multiple pages
pages=("page1" "page2" "page3")
all_data=()

for page in "${pages[@]}"; do
    echo "Processing $page"
    nav g "https://example.com/$page"
    nav wait_idle
    
    # Extract tables
    tables=$(nav tables)
    
    # Append to collection
    all_data+=("$tables")
    
    # Small delay between requests
    sleep 2
done

# Combine all extracted data
printf '%s\n' "${all_data[@]}" > combined_data.json
```

## Advanced Session Management

### Multi-Account Session Handling
```bash
# Create separate sessions for different accounts
nav load_session "user1"
nav g https://example.com/dashboard1
nav save_session "user1_data"

nav load_session "user2" 
nav g https://example.com/dashboard2
nav save_session "user2_data"

# Load specific session for targeted extraction
nav load_session "user1"
nav tables  # Get user1's data
```

### Session Recovery
```bash
# Save state before risky operation
nav save_session "before_extraction"

# Perform risky extraction
nav g https://example.com/risky-page

# If something goes wrong, recover
nav load_session "before_extraction"
```

## Performance Optimization

### Concurrent Operations
```bash
# Use background processes for non-blocking operations
nav g https://example.com/page1 &
nav g https://example.com/page2 &

wait  # Wait for all background jobs

# Process results
nav tables
nav paragraphs
```

### Caching Strategies
```bash
# Check if we already have data for this URL
if [ -f "cache/$(echo $url | md5sum | cut -d' ' -f1).json" ]; then
    echo "Using cached data"
    cat "cache/$(echo $url | md5sum | cut -d' ' -f1).json"
else
    echo "Fetching fresh data"
    nav g $url
    nav tables > "cache/$(echo $url | md5sum | cut -d' ' -f1).json"
fi
```

### Resource Management
```bash
# Clean up between extractions
nav clear_cookies  # Clear cookies if needed
nav quit          # Close browser
nav-server       # Restart fresh
```

## Monitoring and Debugging

### Detailed Logging
```bash
# Capture detailed execution logs
exec 2>&1 | tee execution.log

# Log page state at each step
nav g https://example.com/page
nav state >> page_states.log
nav elements >> elements.log
nav tables >> data.log
```

### Health Checks
```bash
# Verify extraction success
verify_extraction() {
    local data="$1"
    
    if echo "$data" | grep -q "error"; then
        echo "ERROR: Extraction failed"
        return 1
    elif echo "$data" | grep -q "No data"; then
        echo "WARNING: No data extracted"
        return 2
    else
        echo "SUCCESS: Data extracted successfully"
        return 0
    fi
}

# Use health check
result=$(nav tables)
verify_extraction "$result"
```

### Progress Tracking
```bash
# Track extraction progress
total_pages=10
current_page=1

while [ $current_page -le $total_pages ]; do
    echo "Progress: $current_page/$total_pages"
    
    nav g "https://example.com/page/$current_page"
    nav tables
    
    current_page=$((current_page + 1))
done