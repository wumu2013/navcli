---
name: Explore
description: This skill should be used when the user asks to "extract data from websites", "scrape tables from web pages", "get paragraphs from articles", "explore websites for structured data", "browse and extract content", "navigate websites and extract information", or "use NavCLI for data extraction".
version: 0.1.0
---

# Explore

## Overview
Browser automation skill for extracting structured data from websites using NavCLI. Focuses on tables, paragraphs, and interactive content extraction through intelligent browsing workflows.

## When to Use
- Extracting tabular data from financial websites or listings
- Scraping large text paragraphs from articles and documentation  
- Exploring single-page applications for structured content
- Handling pagination for multi-page data extraction
- Automated browsing with data extraction workflows

## How to Use

### Essential Setup
```bash
pip install navcli
nav-server  # Start the NavCLI server
```

### Core Data Extraction Commands

**Priority Commands for Data Extraction:**
```bash
nav tables          # Extract ALL tables with structured data
nav paragraphs      # Get large text paragraphs (200+ chars, default)
nav paragraphs 500 # Get paragraphs with 500+ chars minimum
nav g <url>        # Navigate (auto-returns paragraphs)
```

**Navigation & Interaction:**
```bash
nav g <url>         # Navigate to URL
nav elements        # Get interactive elements
nav find <text>     # Find elements containing text
nav findall <text>  # Find all elements containing text
nav c <selector>    # Click element
nav wait_idle       # Wait for network idle
```

### Agent Workflow Pattern
```bash
# 1 Navigate - Go to target page
nav g https://example.com/data-page

# 2 Observe - Check what data is available  
nav tables                    # PRIORITY: Extract tabular data
nav paragraphs                # PRIORITY: Extract text content
nav elements                  # Find interactive elements

# 3 Interact - Navigate/paginate if needed
nav find "Next"               # Find pagination
nav c "a.next-page"           # Click next page
nav wait_idle                 # Wait for load

# 4 Feedback - Verify data extraction
nav tables                    # Extract updated table
nav paragraphs                # Extract new content

# 5 Continue - Proceed to next data source
nav g https://example.com/page2
nav tables
```

### Complete Command Reference

**Navigation:**
- `nav g <url>` - Navigate to URL
- `nav b` - Go back in history  
- `nav f` - Go forward in history
- `nav r` - Reload current page

**Interaction:**
- `nav c <sel> [--force]` - Click element
- `nav t <sel> <txt>` - Type text into input
- `nav dblclick <sel>` - Double-click element
- `nav clear <sel>` - Clear input field

**Query & Extraction:**
- `nav elements` - Get interactive elements
- `nav text` - Get page text content
- `nav html` - Get page HTML content  
- `nav tables` - Get all tables with data
- `nav paragraphs` - Get paragraphs (min 200 chars)
- `nav links` - Get all hyperlinks
- `nav forms` - Get all forms
- `nav find <text>` - Find first element containing text
- `nav findall <text>` - Find all elements containing text

**Session Management:**
- `nav save_session <name>` - Save session
- `nav load_session <name>` - Load session (for authenticated access)

## Examples

### Extract Financial Data Tables
```bash
# Navigate to financial data page
nav g https://example.com/financial-data

# Extract all structured tables
nav tables

# Get detailed text content
nav paragraphs 500
```

### Multi-Page Article Extraction
```bash
# Navigate to article
nav g https://example.com/long-article

# Extract main content
nav paragraphs

# Find and navigate pagination
nav findall "Next"
nav c "a.next-page"
nav wait_idle

# Continue extraction
nav paragraphs
```

### Interactive Data Exploration
```bash
# Start on listing page
nav g https://example.com/items

# Find interactive elements
nav elements

# Set filters and extract
nav find "Filter"
nav c "select[name='category']"
nav t "input[name='search']" "widget"
nav c "button.apply-filters"

# Extract filtered results
nav wait_idle
nav tables
```

### Session Management for Authenticated Sites
```bash
# Save current session after logging in manually
nav save_session jisilu

# Load saved session to access protected data
nav load_session jisilu
nav g https://jisilu.cn/protected-data

# Extract data with authenticated access
nav tables
nav paragraphs
```

## Key Concepts

- **Navigate → Observe → Interact → Feedback → Continue**: Core intelligent browsing pattern
- **Tables Priority**: Always try `nav tables` first for structured data
- **Paragraphs Priority**: Use `nav paragraphs` for large text content extraction  
- **Session Management**: Use `nav load_session <name>` for authenticated websites
- **Wait for Idle**: Always use `nav wait_idle` after interactions for slow pages

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Empty tables | Run `nav wait_idle` then retry `nav tables` |
| Not logged in | Use `nav load_session <name>` |
| Element not found | Re-run `nav elements` to refresh |
| Timeout issues | Use `nav wait_idle 10` for slow pages |
| Need more data | Try `nav paragraphs` for text content |
| Need specific data | Use `nav find <text>` to locate elements |

## See Also
- All commands follow the pattern `nav <action> <parameters>`
- For complex pagination, use `nav findall <text>` and `nav c <selector>` combinations
- Always use `nav wait_idle` after interactions for reliable data extraction