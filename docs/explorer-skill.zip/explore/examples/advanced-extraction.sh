#!/bin/bash
# Advanced NavCLI Data Extraction with Pagination and Error Handling
# Extract data from multiple pages with robust error handling

set -e

# Configuration
BASE_URL="https://example.com/products"
MAX_PAGES=50
OUTPUT_DIR="extracted_data"
SESSION_NAME="product_extraction"

# Create output directory
mkdir -p "$OUTPUT_DIR"

echo "=== Advanced Multi-Page Data Extraction ==="
echo "Target URL: $BASE_URL"
echo "Max pages: $MAX_PAGES"
echo "Output directory: $OUTPUT_DIR"

# Start server if not running
if ! pgrep -f "nav-server" > /dev/null; then
    echo "Starting NavCLI server..."
    nav-server --headless &
    sleep 5
else
    echo "NavCLI server already running"
fi

# Function to extract page data with error handling
extract_page() {
    local page_num=$1
    local page_url="${BASE_URL}?page=${page_num}"
    local output_file="${OUTPUT_DIR}/page_${page_num}_data.json"
    
    echo "--- Processing page $page_num ---"
    
    # Navigate to page with retry logic
    local attempts=0
    local max_attempts=3
    
    while [ $attempts -lt $max_attempts ]; do
        echo "Navigation attempt $((attempts + 1)) to page $page_num"
        
        if nav g "$page_url"; then
            nav wait_idle
            
            # Check for errors
            if nav text | grep -qi "error\|404\|500"; then
                echo "Page loaded with error, retrying..."
                attempts=$((attempts + 1))
                sleep 3
                continue
            fi
            
            break
        else
            echo "Navigation failed, retrying..."
            attempts=$((attempts + 1))
            sleep 3
        fi
    done
    
    if [ $attempts -ge $max_attempts ]; then
        echo "Failed to navigate to page $page_num after $max_attempts attempts"
        return 1
    fi
    
    # Extract tables
    echo "Extracting tables from page $page_num..."
    if nav tables > "$output_file"; then
        echo "Successfully extracted page $page_num"
        
        # Log extraction success
        echo "Page $page_num: SUCCESS" >> "${OUTPUT_DIR}/extraction_log.txt"
        
        # Show preview of extracted data
        if command -v jq > /dev/null; then
            local row_count=$(jq '.tables[0].rows | length' "$output_file" 2>/dev/null || echo "0")
            echo "Extracted $row_count rows from page $page_num"
        fi
    else
        echo "Failed to extract data from page $page_num"
        echo "Page $page_num: FAILED" >> "${OUTPUT_DIR}/extraction_log.txt"
        return 1
    fi
    
    # Extract paragraphs for context
    nav paragraphs 300 > "${OUTPUT_DIR}/page_${page_num}_paragraphs.json"
    
    return 0
}

# Function to check if more pages exist
has_more_pages() {
    # Look for pagination elements
    if nav findall "a.next" > /dev/null; then
        return 0  # More pages exist
    elif nav findall "a[href*='page=']" > /dev/null; then
        return 0  # Numbered pages exist
    elif nav findall "button.load-more" > /dev/null; then
        return 0  # Load more button exists
    else
        return 1  # No more pages
    fi
}

# Function to save progress
save_progress() {
    local current_page=$1
    echo "$current_page" > "${OUTPUT_DIR}/last_page.txt"
    nav save_session "$SESSION_NAME"
    echo "Progress saved at page $current_page"
}

# Main extraction loop
echo "Starting extraction loop..."

# Check for existing progress
if [ -f "${OUTPUT_DIR}/last_page.txt" ]; then
    last_page=$(cat "${OUTPUT_DIR}/last_page.txt")
    echo "Resuming from page $last_page"
    nav load_session "$SESSION_NAME"
    start_page=$((last_page + 1))
else
    start_page=1
fi

# Extract data page by page
for ((page=$start_page; page<=MAX_PAGES; page++)); do
    echo ""
    echo "=== PAGE $page of $MAX_PAGES ==="
    
    # Extract current page
    if extract_page $page; then
        save_progress $page
        
        # Check if more pages exist
        if ! has_more_pages; then
            echo "No more pages detected, stopping extraction"
            break
        fi
        
        # Navigate to next page if using "Next" button
        if nav findall "a.next" > /dev/null; then
            echo "Clicking 'Next' button..."
            nav c "a.next"
            nav wait_idle
        fi
        
        # Respectful delay between pages
        echo "Waiting 3 seconds before next page..."
        sleep 3
    else
        echo "Failed to extract page $page, continuing to next..."
        echo "Continuing despite failure..."
        sleep 5
    fi
done

# Final processing
echo ""
echo "=== Extraction Complete ==="

# Combine all extracted data
if command -v jq > /dev/null; then
    echo "Combining extracted data..."
    
    # Combine all page data
    jq -s 'add' "${OUTPUT_DIR}"/page_*_data.json > "${OUTPUT_DIR}/combined_data.json"
    
    # Generate summary
    local total_rows=$(jq '[.[].tables[].rows[]] | length' "${OUTPUT_DIR}/combined_data.json")
    local total_tables=$(jq '[.[].tables[]] | length' "${OUTPUT_DIR}/combined_data.json")
    
    echo "Extraction Summary:"
    echo "- Total pages processed: $((page - 1))"
    echo "- Total tables extracted: $total_tables"
    echo "- Total rows extracted: $total_rows"
    echo "- Output files saved in: $OUTPUT_DIR"
    
    echo "Extraction Summary:" > "${OUTPUT_DIR}/summary.txt"
    echo "Total pages processed: $((page - 1))" >> "${OUTPUT_DIR}/summary.txt"
    echo "Total tables extracted: $total_tables" >> "${OUTPUT_DIR}/summary.txt"
    echo "Total rows extracted: $total_rows" >> "${OUTPUT_DIR}/summary.txt"
else
    echo "jq not available, skipping data combination"
fi

# Save final session
nav save_session "$SESSION_NAME"

echo "Data extraction completed successfully!"
echo "Check $OUTPUT_DIR/ for all extracted data files"