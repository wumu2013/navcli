#!/usr/bin/env python3
"""
Advanced NavCLI Data Extraction Script
Uses JSON configuration for intelligent, multi-site data extraction
"""

import json
import os
import sys
import time
import subprocess
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional


class NavCLIExtractor:
    def __init__(self, config_path: str):
        """Initialize extractor with configuration"""
        self.config = self.load_config(config_path)
        self.output_dir = Path(self.config["global_settings"]["output_directory"])
        self.output_dir.mkdir(exist_ok=True)

        # Setup logging
        if self.config["global_settings"]["enable_logging"]:
            logging.basicConfig(
                level=logging.INFO,
                format="%(asctime)s - %(levelname)s - %(message)s",
                handlers=[
                    logging.FileHandler(self.output_dir / "extraction.log"),
                    logging.StreamHandler(),
                ],
            )
            self.logger = logging.getLogger(__name__)
        else:
            self.logger = logging.getLogger(__name__)
            self.logger.disabled = True

    def load_config(self, config_path: str) -> Dict[str, Any]:
        """Load extraction configuration from JSON file"""
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Configuration file {config_path} not found")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"Invalid JSON in configuration file: {e}")
            sys.exit(1)

    def run_navcli_command(self, command: str, timeout: int = 30) -> Optional[str]:
        """Execute NavCLI command and return output"""
        try:
            # This would integrate with NavCLI API or CLI
            # For demonstration, showing the pattern
            result = subprocess.run(
                f"nav {command}", shell=True, capture_output=True, text=True, timeout=timeout
            )

            if result.returncode == 0:
                return result.stdout
            else:
                self.logger.error(f"Command failed: {command}")
                self.logger.error(f"Error: {result.stderr}")
                return None

        except subprocess.TimeoutExpired:
            self.logger.error(f"Command timed out: {command}")
            return None
        except Exception as e:
            self.logger.error(f"Error executing command: {e}")
            return None

    def extract_site_data(self, site_config: Dict[str, Any]) -> Dict[str, Any]:
        """Extract data from a single site based on configuration"""
        site_name = site_config["name"]
        base_url = site_config["base_url"]
        max_pages = site_config["max_pages"]
        selectors = site_config["selectors"]
        options = site_config["extraction_options"]

        self.logger.info(f"Starting extraction for {site_name}")

        site_output_dir = self.output_dir / site_name.lower().replace(" ", "_")
        site_output_dir.mkdir(exist_ok=True)

        extraction_results = {
            "site_name": site_name,
            "base_url": base_url,
            "pages_processed": 0,
            "total_rows": 0,
            "total_tables": 0,
            "errors": [],
        }

        try:
            # Start with page 1
            for page_num in range(1, max_pages + 1):
                page_url = f"{base_url}?page={page_num}"
                self.logger.info(f"Processing page {page_num} of {max_pages}")

                # Navigate to page
                if not self.run_navcli_command(f"g {page_url}"):
                    error_msg = f"Failed to navigate to page {page_num}"
                    self.logger.error(error_msg)
                    extraction_results["errors"].append(error_msg)
                    continue

                # Wait for page to load
                self.run_navcli_command(f"wait_idle {options['wait_timeout']}")

                # Extract tables
                tables_result = self.run_navcli_command("tables")
                if tables_result:
                    # Save page data
                    page_file = site_output_dir / f"page_{page_num}_tables.json"
                    with open(page_file, "w") as f:
                        f.write(tables_result)

                    # Update counters
                    extraction_results["pages_processed"] += 1

                    # Parse and count data (simplified)
                    try:
                        tables_data = json.loads(tables_result)
                        if "tables" in tables_data:
                            for table in tables_data["tables"]:
                                if "rows" in table:
                                    extraction_results["total_rows"] += len(table["rows"])
                                    extraction_results["total_tables"] += 1
                    except json.JSONDecodeError:
                        pass

                # Extract paragraphs
                paragraphs_result = self.run_navcli_command(
                    f"paragraphs {options['min_paragraph_length']}"
                )
                if paragraphs_result:
                    page_file = site_output_dir / f"page_{page_num}_paragraphs.json"
                    with open(page_file, "w") as f:
                        f.write(paragraphs_result)

                # Check for more pages
                if not self.check_pagination(selectors):
                    self.logger.info(f"No more pages found for {site_name}")
                    break

                # Navigate to next page
                if selectors.get("pagination_next"):
                    self.run_navcli_command(f'c "{selectors["pagination_next"]}"')
                    self.run_navcli_command(f"wait_idle {options['wait_timeout']}")
                elif selectors.get("load_more"):
                    self.run_navcli_command(f'c "{selectors["load_more"]}"')
                    self.run_navcli_command(f"wait_idle {options['wait_timeout']}")

                # Rate limiting
                delay = self.config["global_settings"]["rate_limit_delay"]
                self.logger.info(f"Waiting {delay} seconds before next page...")
                time.sleep(delay)

        except Exception as e:
            error_msg = f"Error extracting from {site_name}: {str(e)}"
            self.logger.error(error_msg)
            extraction_results["errors"].append(error_msg)

        return extraction_results

    def check_pagination(self, selectors: Dict[str, Any]) -> bool:
        """Check if more pages are available"""
        # Check for next button
        if selectors.get("pagination_next"):
            result = self.run_navcli_command(f'findall "{selectors["pagination_next"]}"')
            return result is not None and len(result.strip()) > 0

        # Check for load more button
        if selectors.get("load_more"):
            result = self.run_navcli_command(f'findall "{selectors["load_more"]}"')
            return result is not None and len(result.strip()) > 0

        return False

    def combine_site_data(self, site_config: Dict[str, Any], results: Dict[str, Any]) -> None:
        """Combine extracted data from a site"""
        if not self.config["data_processing"]["combine_output"]:
            return

        site_name = site_config["name"]
        site_output_dir = self.output_dir / site_name.lower().replace(" ", "_")

        # Combine all page data
        page_files = list(site_output_dir.glob("page_*_tables.json"))
        if page_files:
            combined_file = site_output_dir / "combined_data.json"

            # This would combine all JSON files
            # Implementation depends on NavCLI output format
            self.logger.info(f"Combined {len(page_files)} page files for {site_name}")

    def generate_csv_output(self, site_config: Dict[str, Any]) -> None:
        """Generate CSV files from extracted data"""
        if not self.config["data_processing"]["generate_csv"]:
            return

        site_name = site_config["name"]
        site_output_dir = self.output_dir / site_name.lower().replace(" ", "_")
        combined_file = site_output_dir / "combined_data.json"

        if combined_file.exists():
            csv_file = site_output_dir / "data.csv"
            # Convert JSON to CSV
            # Implementation depends on data structure
            self.logger.info(f"Generated CSV file: {csv_file}")

    def run_extraction(self) -> None:
        """Run the complete extraction process"""
        self.logger.info("Starting multi-site data extraction")

        all_results = []

        for site_config in self.config["target_sites"]:
            self.logger.info(f"Processing site: {site_config['name']}")

            # Extract data from site
            site_results = self.extract_site_data(site_config)
            all_results.append(site_results)

            # Post-process data
            self.combine_site_data(site_config, site_results)
            self.generate_csv_output(site_config)

        # Generate final summary
        self.generate_summary_report(all_results)

    def generate_summary_report(self, results: List[Dict[str, Any]]) -> None:
        """Generate a summary report of all extractions"""
        summary_file = self.output_dir / "extraction_summary.json"

        summary = {
            "extraction_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_sites": len(results),
            "sites_processed": len([r for r in results if r["pages_processed"] > 0]),
            "total_pages_processed": sum(r["pages_processed"] for r in results),
            "total_rows_extracted": sum(r["total_rows"] for r in results),
            "total_tables_extracted": sum(r["total_tables"] for r in results),
            "site_results": results,
        }

        with open(summary_file, "w") as f:
            json.dump(summary, f, indent=2)

        self.logger.info(f"Extraction complete! Summary saved to {summary_file}")

        # Print summary to console
        print("\n=== EXTRACTION SUMMARY ===")
        print(f"Sites processed: {summary['sites_processed']}/{summary['total_sites']}")
        print(f"Total pages: {summary['total_pages_processed']}")
        print(f"Total rows: {summary['total_rows_extracted']}")
        print(f"Total tables: {summary['total_tables_extracted']}")


def main():
    """Main execution function"""
    if len(sys.argv) != 2:
        print("Usage: python advanced_extraction.py <config.json>")
        sys.exit(1)

    config_path = sys.argv[1]

    # Check if config file exists
    if not os.path.exists(config_path):
        print(f"Configuration file not found: {config_path}")
        sys.exit(1)

    # Initialize and run extractor
    extractor = NavCLIExtractor(config_path)
    extractor.run_extraction()


if __name__ == "__main__":
    main()
