#!/bin/bash
# Basic NavCLI Data Extraction Example
# Extract financial data from a sample website

set -e  # Exit on any error

echo "=== Basic Financial Data Extraction ==="

# Start NavCLI server (assumes already running in background)
echo "Starting NavCLI server..."
nav-server --headless &

# Wait for server to start
sleep 5

# Navigate to financial data page
echo "Navigating to financial data page..."
nav g https://example.com/financial-data

# Wait for page to load
nav wait_idle

# Extract all tables (this is the PRIORITY command for structured data)
echo "Extracting financial tables..."
nav tables

# Extract large text paragraphs for context
echo "Extracting paragraph content..."
nav paragraphs 500

# Get page title and URL for reference
echo "Page information:"
nav title
nav url

# Extract specific interactive elements for potential filtering
echo "Available interactive elements:"
nav elements | head -10

# Save session for future use
echo "Saving session..."
nav save_session "financial_extraction"

echo "=== Basic extraction completed ==="